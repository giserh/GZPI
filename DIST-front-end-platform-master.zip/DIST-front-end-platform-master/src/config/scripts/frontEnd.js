/**
 * Created by Lxg on 2017/6/17.
 */

import frontEnd from '../../modules/frontEnd';

let frontEndModule = [];
frontEndModule.push(frontEnd);

export default frontEndModule;
