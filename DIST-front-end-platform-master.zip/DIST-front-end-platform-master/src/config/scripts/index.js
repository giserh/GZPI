/**
 * Created by Lxg on 2017/6/12.
 */

import common from './common';
import frontEnd from './frontEnd';

let scripts = [];
scripts = scripts.concat(common);
scripts = scripts.concat(frontEnd);

export default scripts;
