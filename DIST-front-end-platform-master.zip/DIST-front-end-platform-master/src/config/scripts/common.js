/**
 * Created by Lxg on 2017/6/12.
 */

import header from '../../components/header';
import footer from '../../components/footer';
import sidebar from '../../components/sidebar';
import tabList from '../../components/tabList';

let commonModule = [];
commonModule.push(header);
commonModule.push(footer);
commonModule.push(sidebar);
commonModule.push(tabList);

export default commonModule;
