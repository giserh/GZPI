/**
 * Created by Lxg on 2017/6/15.
 */

let path = {};

path.common = {};
path.frontEnd = {};

export default path;
