/**
 * Created by Lxg on 2017/6/17.
 */

import './footer.less';
import FooterController from './FooterController';

export default {
  controller: FooterController
};
