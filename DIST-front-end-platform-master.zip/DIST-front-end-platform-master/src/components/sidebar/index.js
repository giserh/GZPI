/**
 * Created by Lxg on 2017/6/13.
 */

import './sidebar.less';
import sidebarDirective from './sidebarDirective';

export default {
  directive: sidebarDirective
};
