/**
 * Created by Lxg on 2017/6/12.
 */

function HeaderController($scope) {
  let vm = $scope.vm = {};

}

HeaderController.$inject = ['$scope'];
HeaderController.controllerName = 'HeaderController';

export default HeaderController;
