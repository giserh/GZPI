/**
 * Created by Lxg on 2017/6/12.
 */

import './header.less';
import HeaderController from './HeaderController';

export default {
  controller: HeaderController
};
