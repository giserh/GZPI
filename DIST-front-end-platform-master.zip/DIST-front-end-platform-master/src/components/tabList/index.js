/**
 * Created by Lxg on 2017/6/13.
 */

import './tabList.less';
import tabList from './tabList';

export default {
  directive: tabList
};
