/**
 * Created by Lxg on 2017/6/17.
 */

import './frontEnd.less';
import frontEndService from './frontEndService';
import FrontEndController from './FrontEndController';

export default {
  service: frontEndService,
  controller: FrontEndController
};
