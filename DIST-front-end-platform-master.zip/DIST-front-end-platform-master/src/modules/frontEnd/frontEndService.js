/**
 * Created by Lxg on 2017/6/17.
 */

function frontEndService() {

}

frontEndService.$inject = [];
frontEndService.serviceName = 'frontEndService';

export default frontEndService;
