/**
 * Created by Lxg on 2017/6/12.
 */

import headerService from '../../../components/header/headerService';

let commonServices = [];
commonServices.push(headerService);

export default commonServices;
