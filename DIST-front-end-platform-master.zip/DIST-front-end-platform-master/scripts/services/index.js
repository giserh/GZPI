/**
 * Created by Lxg on 2017/6/12.
 */

import commonServices from './common';

let services = [];
services = services.concat(commonServices);

export default services;
