/**
 * Created by Lxg on 2017/6/12.
 */

import commonControllers from './common';

let controllers = [];
controllers = controllers.concat(commonControllers);

export default controllers;
