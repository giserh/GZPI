/**
 * Created by Lxg on 2017/6/12.
 */

import HeaderController from '../../../components/header/HeaderController';
import SidebarController from '../../../components/sidebar/SidebarController';

let commonControllers = [];
commonControllers.push(HeaderController);
commonControllers.push(SidebarController);

export default commonControllers;
